﻿using System;

[Serializable] public class PlayerProgressLevel
{
    public float fireballDamage;
    public float grenadeDamage;
    public float experienceForTheNextLevel;
}
